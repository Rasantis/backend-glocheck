from flask import Flask, request, render_template, send_file, redirect, flash, url_for, send_from_directory
import os
from werkzeug.utils import secure_filename
import datetime
import magic
from flask_mail import Mail, Message



app = Flask(__name__)
mail=Mail(app)
app.secret_key = '123456789'

app.config['MAIL_SERVER'] = 'smtp-mail.outlook.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USERNAME'] = 'Glocheck@outlook.com'
app.config['MAIL_PASSWORD'] = 'Glosa1234'
app.config['MAIL_USE_TLS'] = True
mail = Mail(app)
# caminho da pasta na hospedagem
# UPLOAD_FOLDER = '/home/Rasantis/mysite/repositorio'
# UPLOAD_FOLDER = 'repositorio' #Caminho máquina local
UPLOAD_FOLDER = os.path.join(os.getcwd(), 'repositorio')


# Definindo a lista de usuarios e senhas validos
users = [
    {"username": "admin", "password": "1234", "is_admin": True},
    {"username": "user1", "password": "abcd", "is_admin": False},
    {"username": "user2", "password": "efgh", "is_admin": False},
]

# Rota para exibir o formulario de login


@app.route("/login", methods=["GET"])
def login_form():
    return render_template("index.html")

# Rota para processar o login do usuario


@app.route("/login", methods=["POST"])
def login_submit():
    # Obtendo os valores do formulario de login
    input_username = request.form["username"]
    input_password = request.form["password"]

    # Verificando se o usuario e senha digitados sao validos
    user_found = False
    for user in users:
        if input_username == user["username"] and input_password == user["password"]:
            user_found = True
            if user["is_admin"]:
                # O usuário é o administrador, então redireciona para a página "admin"
                return redirect(url_for("show_repository"))

    if user_found:
        return render_template("repositorio.html")
    else:
        return render_template("error.html")




@app.route('/repositorio', methods=['POST'])
def upload():
    file = request.files['imagem']
    save_path = os.path.join(UPLOAD_FOLDER, secure_filename(file.filename))
    file.save(save_path)
    Nome = request.form.get("Nome")
    Email = request.form.get("email")
    Destino = request.form.get("Destino")
    time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # with open('/home/Rasantis/mysite/submissions.txt', 'a+') as f:
    with open('submissions.txt', 'a+') as f:

        f.write('{} - {} - {} - {}\n'.format(Nome, Email, Destino, file.filename, time))
    return render_template("repositorio.html")


@app.route('/get-file/<filename>')
def get_file(filename):
    file = os.path.join(UPLOAD_FOLDER, filename)
    file_type = magic.from_file(file)
    return send_file(file, mimetype=file_type)
# return send_file(file, mimetype="image/png|image/jpeg|text/csv|application/vnd.ms-excel|text/plain|application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# Rota
@app.route('/arquivos', methods=['GET', 'POST'])
def show_repository():
    if request.method == 'GET':
        # Obtém uma lista de tuplas, onde cada tupla contém o nome do arquivo e a data de criação
        files = [(f, os.stat(os.path.join(UPLOAD_FOLDER, f)).st_ctime) for f in os.listdir(UPLOAD_FOLDER)]

        # Ordena a lista de tuplas pelo elemento de índice 1 (data de criação) em ordem crescente
        files.sort(key=lambda x: x[1])

        # Extrai apenas o nome dos arquivos da lista de tuplas
        files = [f[0] for f in files]

        # Lê o conteúdo dos arquivos e armazena em um dicionário, como feito anteriormente
        file_contents = {}
        for file in files:
            file_path = os.path.join(UPLOAD_FOLDER, file)
            with open(file_path, 'r', encoding='latin-1') as f:
                file_contents[file] = f.read()

        # Renderiza a página HTML com os arquivos ordenados por data de criação
        return render_template('arquivos.html', files=files, os=os, UPLOAD_FOLDER=UPLOAD_FOLDER, file_contents=file_contents)

    elif request.method == 'POST':
        # Obter o nome do arquivo e o arquivo enviado pelo usuário
        file = request.form['filename']
        file_path = os.path.join(UPLOAD_FOLDER, file)
        new_content = request.form['texto']

        # Grava o novo conteúdo do arquivo
        with open(file_path, 'w', encoding='latin-1') as f:
            f.write(new_content)
        
        if os.path.exists(file_path):
            flash('Arquivo editado com sucesso!')
    else:
            flash('Erro ao editar o arquivo')

    return redirect(url_for('show_repository'))


@app.route("/results", methods=['POST', 'GET'])
def result():
    if request.method == "POST":
        # Obtém os detalhes do formulário
        name = request.form['Name']
        subject = request.form['Subject']
        email = request.form['Email']

        # Obtém o arquivo enviado
        file = request.files['file']

        # Cria a mensagem usando os valores do formulário
        msg = Message(subject, sender='Glocheck@outlook.com', recipients=[email])
        msg.body = f"{name} ({email}) enviou uma mensagem:\n\n{subject}"

        # Adiciona o arquivo à mensagem como um anexo
        msg.attach(file.filename, file.content_type, file.read())

        # Envia a mensagem
        mail.send(msg)
        
        return "arquivo enviado com sucesso"


@app.route('/download/<path:filename>')
def download(filename):
  # Verifique se o arquivo existe e tem permissão de leitura
  file_path = os.path.join(UPLOAD_FOLDER, filename)
  if os.path.exists(file_path) and os.access(file_path, os.R_OK):
    # Retorne o arquivo como resposta
    return send_from_directory(UPLOAD_FOLDER, filename, as_attachment=True)
  else:
    # Retorne uma mensagem de erro se o arquivo não existir ou não tiver permissão de leitura
    return 'Erro: arquivo não encontrado ou sem permissão de leitura'


@app.route('/submissions')
def show_submissions():
    with open('submissions.txt', 'r') as f:
        submissions = f.read()
    submissions = "<pre>" + submissions + "</pre>"
    return submissions








# #testes
# def test_login_form(client):
#     response = client.get('/login')
#     assert response.status_code == 200
#     assert b'Username' in response.data
#     assert b'Password' in response.data


# def test_login_submit(client):
#     # Teste com usuário e senha válidos
#     response = client.post('/login', data={"username": "admin", "password": "1234"})
#     assert response.status_code == 200
#     assert b'Voce foi autorizado' in response.data

#     # Teste com usuário e senha inválidos
#     response = client.post('/login', data={"username": "admin", "password": "12345"})
#     assert response.status_code == 200
#     assert b'Error' in response.data


# def test_upload(client):
#     # Enviar um arquivo para o servidor
#     response = client.post('/repositorio', data={"Nome": "John", "email": "john@example.com"},
#                            files={"imagem": ("test.png", b"test content", "image/png")})
#     assert response.status_code == 200
#     assert b'Repositorio' in response.data

#     # Verificar se o arquivo foi salvo na pasta repositorio
#     file_path = os.path.join(UPLOAD_FOLDER, "test.png")
#     assert os.path.exists(file_path)
#     assert open(file_path, "rb").read() == b"test content"

#     # Remover o arquivo da pasta repositorio
#     os.remove(file_path)


if __name__ == "__main__":
    app.run(debug=True)